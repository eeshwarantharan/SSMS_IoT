import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class OrderPage extends StatefulWidget {
  const OrderPage({Key? key}) : super(key: key);

  @override
  State<OrderPage> createState() => _OrderPageState();
}


class _OrderPageState extends State<OrderPage> {
  int _currentStep = 0;
  final TextEditingController _productTypeController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();

  Future<void> _sendOrder() async {
    String productId = _productTypeController.text;
    int quantity = int.tryParse(_quantityController.text) ?? 0;

    // Construct the JSON body
    String start = '1001_13604'; // Example start value
    String end = '1001_14103'; // Example end value

    // Update the 'start' value based on the quantity
    // Assuming the start value is a string that can be incremented
    // You may need to implement your own logic to handle this
    int startNum = int.parse(start.split('_')[1]);
    int endNum = int.parse(start.split('_')[1]);
    int cnt = endNum - startNum + 1;
    String updatedEnd = '1001_${endNum - cnt + quantity}';

    final String apiUrl = 'http://52.251.41.188:7898/rfid';

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'rfid': '7364583483',
          'plis': "{\"start\": \"${start}\", \"end\": \"${updatedEnd}\"}",
          'loc': 'Do10, Thunder Avenue, Marcom State',
          'fwid': '1000',
          'twid': '1003',
        }),
      );

      if (response.statusCode == 200) {
        // Handle success
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order placed successfully!')),
        );
      } else {
        // Handle error
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to place order: ${response.statusCode}')),
        );
      }
    } catch (e) {
      // Handle exception
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Order'),
      ),
      body: Stepper(
        currentStep: _currentStep,
        onStepTapped: (step) {
          setState(() {
            _currentStep = step;
          });
        },
        onStepContinue: () {
          if (_currentStep == 2) {
            _sendOrder(); // Send the order when on the last step
          } else {
            setState(() {
              _currentStep++;
            });
          }
        },
        onStepCancel: () {
          setState(() {
            if (_currentStep > 0) {
              _currentStep--;
            }
          });
        },
        steps: [
          Step(
            title: const Text('Shipment Information'),
            content: Column(
              children: [
                SizedBox(height: 16),
                TextField(
                  controller: _productTypeController,
                  decoration: const InputDecoration(
                    hintText: 'Enter Product ID',
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: _quantityController,
                  decoration: const InputDecoration(
                    hintText: 'Enter Quantity',
                  ),
                ),
              ],
            ),
          ),
          Step(
            title: const Text('Barcode Issuance'),
            content: const Text('Show and receive'),
          ),
           Step(
            title: Text('End Operation'),
            content: Text('Success'),
            state: StepState.complete,
          ),
        ],
      ),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }

