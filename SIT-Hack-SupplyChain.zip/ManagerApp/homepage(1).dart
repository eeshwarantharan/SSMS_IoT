import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  Future<Map<String, dynamic>> fetchSensorData() async {
    final url = Uri.parse('http://52.251.41.188:7898/warehouse?wid=1001'); // API URL
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      print('Data received from server: $data');

      // Extract temperature and humidity
      final result = data['result'] as List;
      if (result.isNotEmpty) {
        final firstEntry = result[0];
        final temperature = firstEntry['TEMP'];
        final humidity = firstEntry['HUMIDITY'];
        return {
          'temperature': temperature,
          'humidity': humidity,
        };
      } else {
        throw Exception('Result list is empty');
      }
    } else {
      print('Failed to fetch data. Status code: ${response.statusCode}');
      throw Exception('Failed to fetch data from server');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quality parameters'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder<Map<String, dynamic>>(
          future: fetchSensorData(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                child: Text(
                  'Error: ${snapshot.error}',
                  style: const TextStyle(color: Colors.red),
                ),
              );
            } else if (snapshot.hasData) {
              final data = snapshot.data!;
              final temperature = data['temperature'];
              final humidity = data['humidity'];

              return Column(
                children: [
                  const SizedBox(height: 16),

                  buildCard(
                    title: 'Humidity',
                    value: humidity.toDouble(),
                    unit: '%',
                     
                  ),
                  const SizedBox(height: 16),
                  buildCard(
                    title: 'Temperature',
                    value: temperature.toDouble(),
                    unit: '°C',
                  ),
                ],
              );
            } else {
              return const Center(child: Text('No data available'));
            }
          },
        ),
      ),
    );
  }

  Widget buildCard({
    required String title,
    required double value,
    required String unit,
    IconData? icon,
  }) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      elevation: 4,
      color: Color.fromARGB(217, 222, 201, 12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Center(
              child: SizedBox(
                height: 150,
                width: 150,
                child: SfRadialGauge(
                  axes: <RadialAxis>[
                    RadialAxis(
                      minimum: 0,
                      maximum: 100,
                      showLabels: false,
                      showTicks: false,
                      axisLineStyle: const AxisLineStyle(
                        thickness: 0.2,
                        thicknessUnit: GaugeSizeUnit.factor,
                        color: Color.fromARGB(255, 224, 224, 224),
                      ),
                      pointers: <GaugePointer>[
                        RangePointer(
                          value: value,
                          width: 0.2,
                          sizeUnit: GaugeSizeUnit.factor,
                          color: Colors.teal,
                        ),
                      ],
                      annotations: <GaugeAnnotation>[
                        GaugeAnnotation(
                          widget: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (icon != null)
                                Icon(
                                  icon,
                                  size: 24,
                                  color: Colors.teal,
                                ),
                              Text(
                                '${value.toStringAsFixed(2)} $unit',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          positionFactor: 0.1,
                          angle: 90,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
