import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class InventoryPage extends StatefulWidget {
  const InventoryPage({super.key});

  get inventoryItems => null;
    @override
  State<InventoryPage> createState() => _InventoryPageState();
}
class _InventoryPageState extends State<InventoryPage> {
  List<InventoryItem> inventoryItems = [];

  @override
  void initState() {
    super.initState();
    _fetchInventoryData();
  }

Future<void> _fetchInventoryData() async {
  final response = await http.get(Uri.parse('http://52.251.41.188:7898/warehouse/inv?wid=1001'));

  if (response.statusCode == 200) {
    // Print the response body to understand its structure
    print('Response body: ${response.body}');

    final data = jsonDecode(response.body);

    // Access the 'result' key
    if (data['result'] is List) {
      setState(() {
        inventoryItems = (data['result'] as List).map((item) {
          final title = item['PPID']?.toString() ?? 'Unknown'; // Convert to String and default to 'Unknown' if null
          final stock = item['CNT'] ?? 0; // Default to 0 if null
          return InventoryItem(
            title: title,
            stock: stock,
          );
        }).toList();
      });
    } else {
      print('Expected a list under the "result" key');
    }
  } else {
    print('Failed to fetch data');
  }
    Future<void> updateStock(String ppid, int quantity) async {

    final response = await http.patch(

      Uri.parse('http://52.251.41.188:7898/warehouse/inv?wid=1001'),

      headers: {'Content-Type': 'application/json'},

      body: jsonEncode({

        'PPID': ppid,

        'CNT': quantity,

      }),

    );


    if (response.statusCode == 200) {

      // Successfully updated stock

      _fetchInventoryData(); // Refresh inventory data

    } else {

      print('Failed to update stock');

    }

  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory'),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.add),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.filter_list),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: inventoryItems.length,
        itemBuilder: (context, index) {
          return inventoryItems[index];
        },
      ),
    );
  }
    List<InventoryItem> getInventoryItems() {
    return inventoryItems;

  }
}
class InventoryItem extends StatelessWidget {
  const InventoryItem({
    Key? key,
    required this.title,
    required this.stock,
    //required this.status,
  }) : super(key: key);
 final String title;
  final int stock;
  //final String status;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        title: Text(title),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Stock: $stock'),
            //Text('Status: $status'),
          ],
        ),
      ),
    );
  }
} 

