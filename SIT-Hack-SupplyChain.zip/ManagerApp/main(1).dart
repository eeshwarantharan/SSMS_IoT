import 'package:flutter/material.dart';
import 'homepage.dart'; 
import 'inventory.dart';
import 'home.dart';
import 'order.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Warehouse Manager Application',
      home: WarehouseManagerApp(),
    );
  }
}

class WarehouseManagerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset("assets/home.png"), // Replace with your actual image path
            const SizedBox(height: 25),
            const Text(
              'Warehouse Manager Application',
              style: TextStyle(
                fontSize: 24,
                //fontWeight: FontWeight.bold,
                color: Color.fromARGB(217, 222, 201, 12),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Home()), // Navigate to HomePage
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellow,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text('Get Started'),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
