import 'package:flutter/material.dart';
import 'package:manager_app/order.dart';
import 'homepage.dart'; 
import 'inventory.dart';
class Home extends StatelessWidget {

  const Home({Key? key}) : super(key: key);


  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text('Home Page'),

      ),

      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            ElevatedButton(

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.yellow, // Background color

              ),

              onPressed: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(builder: (context) => const InventoryPage()),

                );

              },

              child: const Text('Inventory'),

            ),
              const SizedBox(height: 20),
              ElevatedButton(

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.yellow, // Background color

              ),

              onPressed: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(builder: (context) => const OrderPage()),

                );

              },

              child: const Text('New Order'),

            ),


            const SizedBox(height: 20),

            ElevatedButton(

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.yellow, // Background color

              ),

              onPressed: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(builder: (context) => HomePage()),

                );

              },

              child: const Text('Quality Parameter'),

            ),

          ],

        ),

      ),

    );

  }

}


