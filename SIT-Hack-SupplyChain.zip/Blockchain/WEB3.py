import requests
import json
from web3 import Web3

# Connect to local blockchain (Ganache)
ganache_url = "http://127.0.0.1:7545"  # Replace with your Ganache RPC server
web3 = Web3(Web3.HTTPProvider(ganache_url))

# Check connection
if not web3.is_connected():
    print("Failed to connect to the blockchain!")
    exit()

# Contract details
contract_address = "0x38C48F6D0A77E1F9b39FDa5c2Af4c49633a4c257"  # Replace with your deployed contract address
contract_abi = json.loads('''[
    {
        "constant": false,
        "inputs": [
            {"name": "RLID", "type": "uint256"},
            {"name": "RFID", "type": "string"},
            {"name": "WID", "type": "uint256"},
            {"name": "PLISStart", "type": "string"},
            {"name": "PLISEnd", "type": "string"},
            {"name": "TSTMP", "type": "string"},
            {"name": "LOC", "type": "string"},
            {"name": "PARENT", "type": "uint256"}
        ],
        "name": "storeData",
        "outputs": [],
        "payable": false,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "getAllRecords",
        "outputs": [{"name": "", "type": "uint256[]"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [{"name": "RLID", "type": "uint256"}],
        "name": "getRecord",
        "outputs": [
            {"name": "RLID", "type": "uint256"},
            {"name": "RFID", "type": "string"},
            {"name": "WID", "type": "uint256"},
            {"name": "PLISStart", "type": "string"},
            {"name": "PLISEnd", "type": "string"},
            {"name": "TSTMP", "type": "string"},
            {"name": "LOC", "type": "string"},
            {"name": "PARENT", "type": "uint256"},
            {"name": "dataHash", "type": "bytes32"}
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    }
]''')

# Load contract
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

# Cloud API URL
cloud_api_url = "http://52.251.41.188:7898/rfid"

# Fetch data from the cloud API
def fetch_cloud_data():
    try:
        response = requests.get(cloud_api_url)
        if response.status_code == 200:
            data = response.json()
            if data.get("message") == "Data successfully retrieved":
                return data["result"]
        print("Failed to retrieve data, status code:", response.status_code)
    except requests.RequestException as e:
        print("Error fetching data from cloud:", e)
    return None

# Add data to blockchain
def add_to_blockchain(record, account):
    try:
        tx_hash = contract.functions.storeData(
            record["RLID"],
            record["RFID"],
            record["WID"],
            record["PLIS"]["start"],
            record["PLIS"]["end"],
            record["TSTMP"],
            record["LOC"],
            record["PARENT"] or 0
        ).transact({
            "from": account,
            "gas": 3000000
        })
        receipt = web3.eth.wait_for_transaction_receipt(tx_hash)
        print(f"Transaction successful with TxHash: {tx_hash.hex()}")
        return tx_hash.hex()
    except Exception as e:
        print("Error adding data to blockchain:", e)
    return None

# Main script
if __name__ == "__main__":
    # Fetch data from cloud
    cloud_data = fetch_cloud_data()
    if not cloud_data:
        print("Failed to fetch cloud data.")
    else:
        print(f"Fetched {len(cloud_data)} records from cloud.")
        for record in cloud_data:
            tx_hash = add_to_blockchain(record, web3.eth.accounts[0])
            if tx_hash:
                print(f"Added RLID {record['RLID']} to blockchain with TxHash: {tx_hash}")
            else:
                print(f"Failed to add RLID {record['RLID']} to blockchain.")